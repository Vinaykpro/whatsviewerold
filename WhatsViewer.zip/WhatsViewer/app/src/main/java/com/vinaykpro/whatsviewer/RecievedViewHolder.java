package com.vinaykpro.whatsviewer;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

/* compiled from: Adapter */
class RecievedViewHolder extends RecyclerView.ViewHolder {
    LinearLayout fullbackgroundlayout;
    boolean isselected = false;
    TextView recievedmessage;
    TextView recievedtime;
    ConstraintLayout recieverLayout;
    TextView recievername;

    public RecievedViewHolder(View view) {
        super(view);
        this.recieverLayout = (ConstraintLayout) view.findViewById(C1092R.C1095id.reciever_bg_layout);
        this.fullbackgroundlayout = (LinearLayout) view.findViewById(C1092R.C1095id.recieverlayoutfull);
        this.recievername = (TextView) view.findViewById(C1092R.C1095id.textView17);
        this.recievedmessage = (TextView) view.findViewById(C1092R.C1095id.recievedmessage);
        this.recievedtime = (TextView) view.findViewById(C1092R.C1095id.recievedtime);
    }
}
