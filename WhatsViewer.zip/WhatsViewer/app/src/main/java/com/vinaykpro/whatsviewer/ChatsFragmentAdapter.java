package com.vinaykpro.whatsviewer;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.List;
import p006de.hdodenhof.circleimageview.CircleImageView;

public class ChatsFragmentAdapter extends RecyclerView.Adapter {
    public static boolean isopenedfromthisfragment = false;
    public static List<String> names;
    Context context;
    List<Contact> messageList;

    public ChatsFragmentAdapter(List<Contact> list, Context context2) {
        this.messageList = list;
        this.context = context2;
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ChatViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(C1092R.layout.user_chat, viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        final ChatViewHolder chatViewHolder = (ChatViewHolder) viewHolder;
        chatViewHolder.userChatNumber.setText(this.messageList.get(i).getName());
        chatViewHolder.userChatLastMessage.setText(this.messageList.get(i).getLastmessage());
        chatViewHolder.userChatLastTime.setText(this.messageList.get(i).getLastmessagetime());
        chatViewHolder.tablename = this.messageList.get(i).getTablename();
        chatViewHolder.firstname = this.messageList.get(i).getFirstname();
        chatViewHolder.lastname = this.messageList.get(i).getLastname();
        chatViewHolder.name = this.messageList.get(i).getName();
        if (this.messageList.get(i).getBlueticks() == 1) {
            chatViewHolder.blueticks.setVisibility(0);
        } else {
            chatViewHolder.blueticks.setVisibility(8);
        }
        File file = new File(this.context.getApplicationContext().getCacheDir() + "/" + chatViewHolder.tablename + "dp.png");
        if (file.exists()) {
            chatViewHolder.profilepic.setImageURI(Uri.fromFile(file));
        } else if (this.messageList.get(i).getUsercount() > 2) {
            chatViewHolder.profilepic.setImageResource(C1092R.C1094drawable.groupdefaultdp);
        } else {
            chatViewHolder.profilepic.setImageResource(C1092R.C1094drawable.userdefaultdp);
        }
        chatViewHolder.userChatLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(ChatsFragmentAdapter.this.context, MainActivity.class);
                intent.putExtra("tablename", chatViewHolder.tablename);
                intent.putExtra("fname", chatViewHolder.firstname);
                intent.putExtra("sname", chatViewHolder.lastname);
                intent.putExtra("zname", chatViewHolder.name);
                HomeActivity.isfilevalid = true;
                ChatsFragmentAdapter.this.context.startActivity(intent);
            }
        });
    }

    public int getItemCount() {
        return this.messageList.size();
    }

    class ChatViewHolder extends RecyclerView.ViewHolder {
        ImageView blueticks;
        String firstname;
        String lastname;
        String name;
        CircleImageView profilepic;
        String tablename;
        TextView userChatLastMessage;
        TextView userChatLastTime;
        ConstraintLayout userChatLayout;
        TextView userChatNumber;

        public ChatViewHolder(View view) {
            super(view);
            this.userChatLayout = (ConstraintLayout) view.findViewById(C1092R.C1095id.user_chat_bg);
            this.profilepic = (CircleImageView) view.findViewById(C1092R.C1095id.userChatcircleImageView);
            this.userChatNumber = (TextView) view.findViewById(C1092R.C1095id.userChatNumber);
            this.userChatLastMessage = (TextView) view.findViewById(C1092R.C1095id.userChatLastMessage);
            this.userChatLastTime = (TextView) view.findViewById(C1092R.C1095id.userChatLastTime);
            this.blueticks = (ImageView) view.findViewById(C1092R.C1095id.imageView13);
        }
    }
}
