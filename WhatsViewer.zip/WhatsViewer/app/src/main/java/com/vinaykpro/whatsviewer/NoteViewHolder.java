package com.vinaykpro.whatsviewer;

import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

/* compiled from: Adapter */
class NoteViewHolder extends RecyclerView.ViewHolder {
    TextView note;

    public NoteViewHolder(View view) {
        super(view);
        this.note = (TextView) view.findViewById(C1092R.C1095id.note);
    }
}
