package com.vinaykpro.whatsviewer;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsCallback;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    public static List<String> messageList;
    Adapter adapter;
    View backBtn;
    ImageView backbtn;
    Calendar calendar;
    ConstraintLayout chatmenulayout;
    ImageView copy;
    MySqllite database;
    ImageView delete;
    ImageView edit;
    public EditText editText;
    ConstraintLayout editmessagelayout;
    ImageView editmsgbackbtn;
    public EditText editmsgedittext;
    public TextView editmsgupdate;
    String fname;
    ImageView gotolast;
    ImageView info;
    String lastseen = CustomTabsCallback.ONLINE_EXTRAS_KEY;
    LinearLayoutManager linearLayoutManager;
    String myname = "Noname";
    public TextView onlineStatus;
    TextView onlinestatus;
    LinearLayout profilebar;
    public ImageView profilepic;
    RecyclerView recyclerView;
    ConstraintLayout searchlayout;
    ImageView searchlayoutbackbtn;
    ImageView searchlayoutdownbutton;
    public EditText searchlayoutedittext;
    ImageView searchlayoutupbutton;
    public TextView selectedcount;
    public ImageView send;
    SimpleDateFormat simpleDateFormat;
    String sname;
    String tablename;
    int usercount;
    TextView username;

    /* renamed from: v */
    View f172v;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C1092R.layout.activity_main);
        this.database = new MySqllite(this);
        this.recyclerView = (RecyclerView) findViewById(C1092R.C1095id.backg);
        ActionBar supportActionBar = getSupportActionBar();
        Objects.requireNonNull(supportActionBar);
        supportActionBar.hide();
        this.onlineStatus = (TextView) findViewById(C1092R.C1095id.onlinestatus);
        this.editText = (EditText) findViewById(C1092R.C1095id.editTextid);
        this.chatmenulayout = (ConstraintLayout) findViewById(C1092R.C1095id.chatmenulayout);
        this.backbtn = (ImageView) findViewById(C1092R.C1095id.imageView5);
        this.selectedcount = (TextView) findViewById(C1092R.C1095id.textView2);
        this.edit = (ImageView) findViewById(C1092R.C1095id.imageView6);
        this.copy = (ImageView) findViewById(C1092R.C1095id.imageView);
        this.delete = (ImageView) findViewById(C1092R.C1095id.imageView2);
        this.info = (ImageView) findViewById(C1092R.C1095id.imageView4);
        this.editmessagelayout = (ConstraintLayout) findViewById(C1092R.C1095id.editmessagelayout);
        this.editmsgbackbtn = (ImageView) findViewById(C1092R.C1095id.imageView7);
        this.editmsgedittext = (EditText) findViewById(C1092R.C1095id.editmessage);
        this.editmsgupdate = (TextView) findViewById(C1092R.C1095id.textView9);
        this.searchlayout = (ConstraintLayout) findViewById(C1092R.C1095id.searchlayout);
        this.searchlayoutbackbtn = (ImageView) findViewById(C1092R.C1095id.searchlayoutbackbtn);
        this.searchlayoutedittext = (EditText) findViewById(C1092R.C1095id.searchmessage);
        this.searchlayoutupbutton = (ImageView) findViewById(C1092R.C1095id.imageView9);
        this.searchlayoutdownbutton = (ImageView) findViewById(C1092R.C1095id.imageView10);
        this.gotolast = (ImageView) findViewById(C1092R.C1095id.gotolastmessage);
        this.searchlayout.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });
        this.editmessagelayout.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });
        if (HomeActivity.isfilevalid) {
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                this.fname = extras.getString("fname");
                this.sname = extras.getString("sname");
                this.myname = extras.getString("zname");
                this.lastseen = extras.getString("lastseen");
                this.tablename = extras.getString("tablename");
            }
            String str = this.database.getlastseen(this.tablename);
            this.lastseen = str;
            if (this.myname == null) {
                this.myname = "No name";
            }
            if (str == null) {
                this.lastseen = CustomTabsCallback.ONLINE_EXTRAS_KEY;
            }
            View rootView = findViewById(C1092R.C1095id.include).getRootView();
            this.f172v = rootView;
            this.profilepic = (ImageView) rootView.findViewById(C1092R.C1095id.mainactivityprofilepic);
            this.username = (TextView) this.f172v.findViewById(C1092R.C1095id.textView);
            this.profilebar = (LinearLayout) this.f172v.findViewById(C1092R.C1095id.linearLayout2);
            TextView textView = (TextView) this.f172v.findViewById(C1092R.C1095id.onlinestatus);
            this.onlineStatus = textView;
            textView.setText(this.lastseen);
            this.username.setText(this.myname);
            messageList = this.database.getChatData(this.tablename);
            initRecyclerView();
        }
        ImageView imageView = (ImageView) findViewById(C1092R.C1095id.voice_call);
        findViewById(C1092R.C1095id.chat_back_button).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    MainActivity.this.database.updatelastleftmessageindex(MainActivity.this.tablename, MainActivity.this.linearLayoutManager.findFirstCompletelyVisibleItemPosition());
                } catch (Exception unused) {
                }
                MainActivity.this.finish();
            }
        });
        this.send = (ImageView) findViewById(C1092R.C1095id.send);
        this.usercount = this.database.getusercount(this.tablename);
        this.profilebar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                intent.putExtra("tablename", MainActivity.this.tablename);
                intent.putExtra("username", MainActivity.this.myname);
                intent.putExtra("lastseen", MainActivity.this.lastseen);
                intent.putExtra("usercount", MainActivity.this.usercount);
                MainActivity.this.startActivity(intent);
            }
        });
        updatedata();
        this.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            public void onScrolled(RecyclerView recyclerView, int i, int i2) {
                super.onScrolled(recyclerView, i, i2);
                if (MainActivity.this.linearLayoutManager.findLastCompletelyVisibleItemPosition() >= MainActivity.this.linearLayoutManager.getItemCount() - 2) {
                    MainActivity.this.gotolast.setVisibility(8);
                } else {
                    MainActivity.this.gotolast.setVisibility(0);
                }
            }
        });
    }

    private void initRecyclerView() {
        this.recyclerView = (RecyclerView) findViewById(C1092R.C1095id.backg);
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        this.linearLayoutManager = linearLayoutManager2;
        linearLayoutManager2.setOrientation(1);
        this.recyclerView.setLayoutManager(this.linearLayoutManager);
        List<String> list = messageList;
        Adapter adapter2 = r0;
        List<String> list2 = list;
        List<String> list3 = list2;
        Adapter adapter3 = new Adapter(list3, this.tablename, this.fname, this.sname, this, this.chatmenulayout, this.backbtn, this.edit, this.copy, this.delete, this.info, this.selectedcount, this.editmessagelayout, this.editmsgbackbtn, this.editmsgedittext, this.editmsgupdate, this.searchlayout, this.searchlayoutbackbtn, this.searchlayoutedittext, this.searchlayoutupbutton, this.searchlayoutdownbutton, this.linearLayoutManager);
        Adapter adapter4 = adapter2;
        this.adapter = adapter4;
        this.recyclerView.setAdapter(adapter4);
        RecyclerView.ItemAnimator itemAnimator = this.recyclerView.getItemAnimator();
        Objects.requireNonNull(itemAnimator);
        ((SimpleItemAnimator) itemAnimator).setSupportsChangeAnimations(false);
        this.adapter.notifyDataSetChanged();
        int i = this.database.getlastleftmessageindex(this.tablename);
        if (i <= this.adapter.getItemCount() - 1 && i >= 0) {
            this.linearLayoutManager.scrollToPositionWithOffset(i, 5);
        }
    }

    public void onBackPressed() {
        try {
            this.database.updatelastleftmessageindex(this.tablename, this.linearLayoutManager.findFirstCompletelyVisibleItemPosition());
        } catch (Exception unused) {
        }
        if (Adapter.count > 0 || Adapter.issearching) {
            this.backbtn.callOnClick();
        } else {
            super.onBackPressed();
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        this.myname = this.database.getname(this.tablename);
        this.lastseen = this.database.getlastseen(this.tablename);
        this.username.setText(this.myname);
        this.onlineStatus.setText(this.lastseen);
        updatedata();
        super.onResume();
    }

    public void updatedata() {
        try {
            File file = new File(getApplicationContext().getCacheDir() + "/" + this.tablename + "dp.png");
            if (file.exists()) {
                this.profilepic.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            } else if (this.usercount > 2) {
                this.profilepic.setImageResource(C1092R.C1094drawable.groupdefaultdp);
            } else {
                this.profilepic.setImageResource(C1092R.C1094drawable.userdefaultdp);
            }
        } catch (Exception e) {
            Toast.makeText(this, e + "", 0).show();
        }
    }
}
