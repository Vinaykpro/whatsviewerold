package com.vinaykpro.whatsviewer;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Adapter extends RecyclerView.Adapter {
    public static int count = 0;
    public static boolean issearching = false;
    public static int triggeredposition = -1;
    ImageView backbtn;
    ConstraintLayout blacklayoutselectsender;
    ConstraintLayout chatmenulayout;
    ClipboardManager clipboard;
    ClipData cliptext;
    List<String> colorList;
    public Context context;
    ImageView copy;
    MySqllite database;
    List<String> deletableitems = new ArrayList();
    ImageView delete;
    ImageView edit;
    ConstraintLayout editmessagelayout;
    boolean editmode = false;
    ImageView editmsgbackbtn;
    EditText editmsgedittext;
    TextView editmsgupdate;
    ImageView gotolastmessage;
    List<String> groupmemebernames;
    List<String> groupnamesforadapter = new ArrayList();
    List<String> indexes = new ArrayList();
    ImageView info;
    InputMethodManager inputMethodManager;
    public boolean isNightMode = false;
    boolean isthisagroup = false;
    int leastindex = 0;
    LinearLayoutManager linearLayoutManager;
    ConstraintLayout maininputlayout;
    public int membercount = 0;
    List<String> messageList;
    int nearestone = 0;
    PopupMenu popupMenu;
    List<String> searchedIndexes = new ArrayList();
    String searchedword = "";
    ConstraintLayout searchlayout;
    ImageView searchlayoutbackbtn;
    ImageView searchlayoutdownbutton;
    EditText searchlayoutedittext;
    ImageView searchlayoutupbutton;
    TextView selectedcount;
    List<RecievedViewHolder> selectedritems = new ArrayList();
    List<SentViewHolder> selectedsitems = new ArrayList();
    boolean selectionmode = false;
    LinearLayout selectsenderlayout;
    Spinner sendernamechoosingspinner;
    String tablename;
    ImageView threedots;
    String userName1;
    String userName2;

    /* renamed from: v */
    Vibrator f167v;

    public Adapter(List<String> list, String str, String str2, String str3, Context context2, ConstraintLayout constraintLayout, ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4, ImageView imageView5, TextView textView, ConstraintLayout constraintLayout2, ImageView imageView6, EditText editText, TextView textView2, ConstraintLayout constraintLayout3, ImageView imageView7, EditText editText2, ImageView imageView8, ImageView imageView9, LinearLayoutManager linearLayoutManager2) {
        Context context3 = context2;
        this.messageList = list;
        this.userName1 = str2;
        this.userName2 = str3;
        this.context = context3;
        this.chatmenulayout = constraintLayout;
        this.backbtn = imageView;
        this.edit = imageView2;
        this.copy = imageView3;
        this.delete = imageView4;
        this.info = imageView5;
        this.selectedcount = textView;
        this.tablename = str;
        this.editmessagelayout = constraintLayout2;
        this.editmsgbackbtn = imageView6;
        this.editmsgedittext = editText;
        this.editmsgupdate = textView2;
        this.searchlayout = constraintLayout3;
        this.searchlayoutbackbtn = imageView7;
        this.searchlayoutedittext = editText2;
        this.searchlayoutupbutton = imageView8;
        this.searchlayoutdownbutton = imageView9;
        this.linearLayoutManager = linearLayoutManager2;
        MainActivity mainActivity = (MainActivity) context3;
        this.gotolastmessage = (ImageView) mainActivity.findViewById(C1092R.C1095id.gotolastmessage);
        this.sendernamechoosingspinner = (Spinner) mainActivity.findViewById(C1092R.C1095id.spinner);
        this.selectsenderlayout = (LinearLayout) mainActivity.findViewById(C1092R.C1095id.choosesenderlayout);
        this.blacklayoutselectsender = (ConstraintLayout) mainActivity.findViewById(C1092R.C1095id.blanklayout);
        this.maininputlayout = (ConstraintLayout) mainActivity.findViewById(C1092R.C1095id.relativeLayout);
        this.database = new MySqllite(context2);
        this.threedots = (ImageView) mainActivity.findViewById(C1092R.C1095id.three_dots);
        PopupMenu popupMenu2 = new PopupMenu(context2, this.threedots);
        this.popupMenu = popupMenu2;
        popupMenu2.inflate(C1092R.C1097menu.chat_popup_menu);
        this.inputMethodManager = (InputMethodManager) ((MainActivity) this.context).getSystemService("input_method");
        this.f167v = (Vibrator) context2.getSystemService("vibrator");
        this.clipboard = (ClipboardManager) context2.getSystemService("clipboard");
        this.colorList = new ArrayList();
        int i = this.database.getusercount(str);
        this.membercount = i;
        if (i != 2) {
            this.isthisagroup = true;
            this.groupmemebernames = this.database.getUserNames(str);
            ArrayAdapter arrayAdapter = new ArrayAdapter(context2, 17367048, this.groupmemebernames);
            arrayAdapter.setDropDownViewResource(17367049);
            this.sendernamechoosingspinner.setAdapter(arrayAdapter);
            this.sendernamechoosingspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                public void onNothingSelected(AdapterView<?> adapterView) {
                }

                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                    String obj = adapterView.getItemAtPosition(i).toString();
                    if (!obj.equals(Adapter.this.userName1)) {
                        List<String> list = Adapter.this.groupmemebernames;
                        list.remove(obj + "");
                        if (!Adapter.this.groupmemebernames.contains(Adapter.this.userName1)) {
                            Adapter.this.groupmemebernames.add(Adapter.this.userName1);
                        }
                        Adapter.this.userName1 = obj;
                        Adapter.this.notifyDataSetChanged();
                    }
                    Adapter.this.blacklayoutselectsender.setVisibility(8);
                }
            });
            this.blacklayoutselectsender.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    Adapter.this.blacklayoutselectsender.setVisibility(8);
                    return true;
                }
            });
            Random random = new Random();
            for (int i2 = 0; i2 < this.groupmemebernames.size(); i2++) {
                this.colorList.add(String.format("#%06x", new Object[]{Integer.valueOf(random.nextInt(16777216))}));
            }
        }
        this.isNightMode = getNightMode();
    }

    /* access modifiers changed from: private */
    public String getMessage(String str) {
        return str.substring(str.indexOf(":", str.indexOf("-")) + 2);
    }

    /* access modifiers changed from: private */
    public String getName(String str) {
        int indexOf = str.indexOf("-");
        return str.substring(indexOf + 2, str.indexOf(":", indexOf));
    }

    /* access modifiers changed from: private */
    public boolean canigetMessage(String str) {
        int indexOf = str.indexOf("-");
        return (indexOf == -1 || str.indexOf(":", indexOf) == -1) ? false : true;
    }

    /* access modifiers changed from: private */
    public boolean canigetName(String str) {
        int indexOf = str.indexOf("-");
        return (indexOf == -1 || str.indexOf(":", indexOf) == -1) ? false : true;
    }

    /* access modifiers changed from: private */
    public boolean canigetTime(String str) {
        int indexOf = str.indexOf(",");
        return (indexOf == -1 || str.indexOf("-", indexOf) == -1) ? false : true;
    }

    /* access modifiers changed from: private */
    public String getTime(String str) {
        int indexOf = str.indexOf(",");
        return str.substring(indexOf + 2, str.indexOf("-", indexOf) - 1);
    }

    /* access modifiers changed from: private */
    public String getDate(String str) {
        return str.substring(0, str.indexOf(","));
    }

    public int getItemViewType(int i) {
        if (canigetName(this.messageList.get(i))) {
            String name = getName(this.messageList.get(i));
            if (name.equals(this.userName1)) {
                return 0;
            }
            if (this.isthisagroup) {
                if (this.groupmemebernames.contains(name)) {
                    return 1;
                }
                return 2;
            } else if (name.equals(this.userName2)) {
                return 1;
            }
        }
        return 2;
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x009f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public androidx.recyclerview.widget.RecyclerView.ViewHolder onCreateViewHolder(android.view.ViewGroup r10, int r11) {
        /*
            r9 = this;
            android.content.Context r0 = r10.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            java.util.List<java.lang.String> r1 = r9.messageList
            int r2 = r1.size()
            r3 = 1
            int r2 = r2 - r3
            java.lang.Object r1 = r1.get(r2)
            java.lang.String r1 = (java.lang.String) r1
            boolean r1 = r9.canigetName(r1)
            r2 = 0
            if (r1 == 0) goto L_0x00af
            java.util.List<java.lang.String> r1 = r9.messageList
            int r4 = r1.size()
            int r4 = r4 - r3
            java.lang.Object r1 = r1.get(r4)
            java.lang.String r1 = (java.lang.String) r1
            boolean r1 = r9.canigetTime(r1)
            if (r1 == 0) goto L_0x00af
            java.util.List<java.lang.String> r1 = r9.messageList
            int r4 = r1.size()
            int r4 = r4 - r3
            java.lang.Object r1 = r1.get(r4)
            java.lang.String r1 = (java.lang.String) r1
            java.lang.String r1 = r9.getName(r1)
            java.util.List<java.lang.String> r4 = r9.messageList
            int r5 = r4.size()
            int r5 = r5 - r3
            java.lang.Object r4 = r4.get(r5)
            java.lang.String r4 = (java.lang.String) r4
            java.lang.String r4 = r9.getMessage(r4)
            java.util.List<java.lang.String> r5 = r9.messageList
            int r6 = r5.size()
            int r6 = r6 - r3
            java.lang.Object r5 = r5.get(r6)
            java.lang.String r5 = (java.lang.String) r5
            java.lang.String r5 = r9.getTime(r5)
            int r6 = r4.length()
            r7 = 30
            if (r6 <= r7) goto L_0x0088
            java.lang.String r6 = "\n"
            java.lang.String r8 = ""
            java.lang.String r4 = r4.replaceAll(r6, r8)
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r4 = r4.substring(r2, r7)
            r6.append(r4)
            java.lang.String r4 = "..."
            r6.append(r4)
            java.lang.String r4 = r6.toString()
        L_0x0088:
            java.lang.String r6 = r9.userName1     // Catch:{ Exception -> 0x009f }
            boolean r1 = r1.equals(r6)     // Catch:{ Exception -> 0x009f }
            if (r1 == 0) goto L_0x0098
            com.vinaykpro.whatsviewer.MySqllite r1 = r9.database     // Catch:{ Exception -> 0x009f }
            java.lang.String r6 = r9.tablename     // Catch:{ Exception -> 0x009f }
            r1.updateblueticks(r6, r3)     // Catch:{ Exception -> 0x009f }
            goto L_0x009f
        L_0x0098:
            com.vinaykpro.whatsviewer.MySqllite r1 = r9.database     // Catch:{ Exception -> 0x009f }
            java.lang.String r6 = r9.tablename     // Catch:{ Exception -> 0x009f }
            r1.updateblueticks(r6, r2)     // Catch:{ Exception -> 0x009f }
        L_0x009f:
            com.vinaykpro.whatsviewer.MySqllite r1 = r9.database     // Catch:{ Exception -> 0x00ae }
            java.lang.String r6 = r9.tablename     // Catch:{ Exception -> 0x00ae }
            r1.updatelastmessage(r6, r4)     // Catch:{ Exception -> 0x00ae }
            com.vinaykpro.whatsviewer.MySqllite r1 = r9.database     // Catch:{ Exception -> 0x00ae }
            java.lang.String r4 = r9.tablename     // Catch:{ Exception -> 0x00ae }
            r1.updatelastmessagetime(r4, r5)     // Catch:{ Exception -> 0x00ae }
            goto L_0x00af
        L_0x00ae:
        L_0x00af:
            android.widget.ImageView r1 = r9.threedots
            com.vinaykpro.whatsviewer.Adapter$3 r4 = new com.vinaykpro.whatsviewer.Adapter$3
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.gotolastmessage
            com.vinaykpro.whatsviewer.Adapter$4 r4 = new com.vinaykpro.whatsviewer.Adapter$4
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.PopupMenu r1 = r9.popupMenu
            com.vinaykpro.whatsviewer.Adapter$5 r4 = new com.vinaykpro.whatsviewer.Adapter$5
            r4.<init>()
            r1.setOnMenuItemClickListener(r4)
            android.widget.ImageView r1 = r9.backbtn
            com.vinaykpro.whatsviewer.Adapter$6 r4 = new com.vinaykpro.whatsviewer.Adapter$6
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.copy
            com.vinaykpro.whatsviewer.Adapter$7 r4 = new com.vinaykpro.whatsviewer.Adapter$7
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.delete
            com.vinaykpro.whatsviewer.Adapter$8 r4 = new com.vinaykpro.whatsviewer.Adapter$8
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.edit
            com.vinaykpro.whatsviewer.Adapter$9 r4 = new com.vinaykpro.whatsviewer.Adapter$9
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.TextView r1 = r9.editmsgupdate
            com.vinaykpro.whatsviewer.Adapter$10 r4 = new com.vinaykpro.whatsviewer.Adapter$10
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.editmsgbackbtn
            com.vinaykpro.whatsviewer.Adapter$11 r4 = new com.vinaykpro.whatsviewer.Adapter$11
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.EditText r1 = r9.searchlayoutedittext
            com.vinaykpro.whatsviewer.Adapter$12 r4 = new com.vinaykpro.whatsviewer.Adapter$12
            r4.<init>()
            r1.setOnEditorActionListener(r4)
            android.widget.ImageView r1 = r9.searchlayoutupbutton
            com.vinaykpro.whatsviewer.Adapter$13 r4 = new com.vinaykpro.whatsviewer.Adapter$13
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.searchlayoutdownbutton
            com.vinaykpro.whatsviewer.Adapter$14 r4 = new com.vinaykpro.whatsviewer.Adapter$14
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.searchlayoutbackbtn
            com.vinaykpro.whatsviewer.Adapter$15 r4 = new com.vinaykpro.whatsviewer.Adapter$15
            r4.<init>()
            r1.setOnClickListener(r4)
            android.widget.ImageView r1 = r9.info
            com.vinaykpro.whatsviewer.Adapter$16 r4 = new com.vinaykpro.whatsviewer.Adapter$16
            r4.<init>()
            r1.setOnClickListener(r4)
            if (r11 != 0) goto L_0x014a
            r11 = 2131427433(0x7f0b0069, float:1.8476482E38)
            android.view.View r10 = r0.inflate(r11, r10, r2)
            com.vinaykpro.whatsviewer.SentViewHolder r11 = new com.vinaykpro.whatsviewer.SentViewHolder
            r11.<init>(r10)
            return r11
        L_0x014a:
            if (r11 != r3) goto L_0x0159
            r11 = 2131427432(0x7f0b0068, float:1.847648E38)
            android.view.View r10 = r0.inflate(r11, r10, r2)
            com.vinaykpro.whatsviewer.RecievedViewHolder r11 = new com.vinaykpro.whatsviewer.RecievedViewHolder
            r11.<init>(r10)
            return r11
        L_0x0159:
            r1 = 2
            r3 = 2131427434(0x7f0b006a, float:1.8476484E38)
            if (r11 != r1) goto L_0x0169
            android.view.View r10 = r0.inflate(r3, r10, r2)
            com.vinaykpro.whatsviewer.NoteViewHolder r11 = new com.vinaykpro.whatsviewer.NoteViewHolder
            r11.<init>(r10)
            return r11
        L_0x0169:
            android.view.View r10 = r0.inflate(r3, r10, r2)
            com.vinaykpro.whatsviewer.NoteViewHolder r11 = new com.vinaykpro.whatsviewer.NoteViewHolder
            r11.<init>(r10)
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vinaykpro.whatsviewer.Adapter.onCreateViewHolder(android.view.ViewGroup, int):androidx.recyclerview.widget.RecyclerView$ViewHolder");
    }

    /* access modifiers changed from: private */
    public boolean notempty(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ') {
                return true;
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:38:0x012b  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x014e  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x017a  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x01c6  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x01cd  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x01ef  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x02fa  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0323  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x034f  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x039b  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x03a2  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x03c4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onBindViewHolder(androidx.recyclerview.widget.RecyclerView.ViewHolder r18, int r19) {
        /*
            r17 = this;
            r0 = r17
            r1 = r19
            java.util.List<java.lang.String> r2 = r0.messageList
            java.lang.Object r2 = r2.get(r1)
            java.lang.String r2 = (java.lang.String) r2
            boolean r3 = r0.canigetName(r2)
            java.lang.String r4 = ""
            if (r3 == 0) goto L_0x0019
            java.lang.String r3 = r0.getName(r2)
            goto L_0x001a
        L_0x0019:
            r3 = r4
        L_0x001a:
            boolean r5 = r0.canigetMessage(r2)
            if (r5 == 0) goto L_0x0025
            java.lang.String r5 = r0.getMessage(r2)
            goto L_0x0026
        L_0x0025:
            r5 = r4
        L_0x0026:
            boolean r6 = r0.canigetTime(r2)
            if (r6 == 0) goto L_0x0031
            java.lang.String r2 = r0.getTime(r2)
            goto L_0x0032
        L_0x0031:
            r2 = r4
        L_0x0032:
            int r6 = r0.getItemViewType(r1)
            r7 = 2131165322(0x7f07008a, float:1.7944858E38)
            r8 = 2131165314(0x7f070082, float:1.7944842E38)
            java.lang.String r9 = "Messages and calls are end-to-end encrypted. No one outside of this chat"
            r10 = 2131034228(0x7f050074, float:1.7678968E38)
            r11 = 2
            r12 = 1
            if (r6 != r11) goto L_0x00a0
            r2 = r18
            com.vinaykpro.whatsviewer.NoteViewHolder r2 = (com.vinaykpro.whatsviewer.NoteViewHolder) r2
            android.widget.TextView r3 = r2.note
            java.util.List<java.lang.String> r4 = r0.messageList
            java.lang.Object r4 = r4.get(r1)
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r3.setText(r4)
            java.util.List<java.lang.String> r3 = r0.messageList
            java.lang.Object r3 = r3.get(r1)
            java.lang.String r3 = (java.lang.String) r3
            boolean r3 = r3.contains(r9)
            if (r3 == 0) goto L_0x0070
            if (r1 != r12) goto L_0x0070
            boolean r1 = r0.isNightMode
            if (r1 != 0) goto L_0x0070
            android.widget.TextView r1 = r2.note
            r1.setBackgroundResource(r7)
            goto L_0x0075
        L_0x0070:
            android.widget.TextView r1 = r2.note
            r1.setBackgroundResource(r8)
        L_0x0075:
            boolean r1 = r0.isNightMode
            if (r1 == 0) goto L_0x008b
            android.widget.TextView r1 = r2.note
            android.content.Context r2 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r2 = (com.vinaykpro.whatsviewer.MainActivity) r2
            android.content.res.Resources r2 = r2.getResources()
            int r2 = r2.getColor(r10)
            r1.setTextColor(r2)
            goto L_0x009f
        L_0x008b:
            android.widget.TextView r1 = r2.note
            android.content.Context r2 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r2 = (com.vinaykpro.whatsviewer.MainActivity) r2
            android.content.res.Resources r2 = r2.getResources()
            r3 = 2131034736(0x7f050270, float:1.7679998E38)
            int r2 = r2.getColor(r3)
            r1.setTextColor(r2)
        L_0x009f:
            return
        L_0x00a0:
            android.widget.RelativeLayout$LayoutParams r6 = new android.widget.RelativeLayout$LayoutParams
            r13 = -1
            r14 = -2
            r6.<init>(r13, r14)
            java.lang.String r13 = r0.userName1
            boolean r3 = r3.equals(r13)
            java.lang.String r13 = "(?i)"
            java.lang.String r14 = "</span>"
            java.lang.String r15 = "<span style='background-color:yellow'>"
            r16 = r13
            java.lang.String r12 = "alpha"
            r13 = 2131034738(0x7f050272, float:1.7680002E38)
            r11 = 8
            r7 = 0
            if (r3 == 0) goto L_0x023d
            r3 = r18
            com.vinaykpro.whatsviewer.SentViewHolder r3 = (com.vinaykpro.whatsviewer.SentViewHolder) r3
            android.widget.TextView r9 = r3.sentmessage
            r9.setText(r5)
            android.widget.TextView r9 = r3.senttime
            r9.setText(r2)
            r2 = 2131165283(0x7f070063, float:1.7944779E38)
            if (r1 == 0) goto L_0x011a
            java.util.List<java.lang.String> r9 = r0.messageList
            int r8 = r1 + -1
            java.lang.Object r9 = r9.get(r8)
            java.lang.String r9 = (java.lang.String) r9
            boolean r9 = r0.canigetName(r9)
            if (r9 == 0) goto L_0x011a
            java.util.List<java.lang.String> r9 = r0.messageList
            java.lang.Object r8 = r9.get(r8)
            java.lang.String r8 = (java.lang.String) r8
            java.lang.String r8 = r0.getName(r8)
            java.util.Objects.requireNonNull(r8)
            java.lang.String r8 = (java.lang.String) r8
            java.lang.String r9 = r0.userName1
            boolean r8 = r8.equals(r9)
            if (r8 != 0) goto L_0x0109
            r6.setMargins(r7, r11, r7, r7)
            android.widget.LinearLayout r8 = r3.fullbackgroundlayout
            r8.setLayoutParams(r6)
            com.vinaykpro.whatsviewer.ImFlexboxLayout r6 = r3.senderLayout
            r6.setBackgroundResource(r2)
            goto L_0x0127
        L_0x0109:
            r6.setMargins(r7, r7, r7, r7)
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            r2.setLayoutParams(r6)
            com.vinaykpro.whatsviewer.ImFlexboxLayout r2 = r3.senderLayout
            r6 = 2131165284(0x7f070064, float:1.794478E38)
            r2.setBackgroundResource(r6)
            goto L_0x0127
        L_0x011a:
            r6.setMargins(r7, r11, r7, r7)
            android.widget.LinearLayout r8 = r3.fullbackgroundlayout
            r8.setLayoutParams(r6)
            com.vinaykpro.whatsviewer.ImFlexboxLayout r6 = r3.senderLayout
            r6.setBackgroundResource(r2)
        L_0x0127:
            boolean r2 = r0.isNightMode
            if (r2 == 0) goto L_0x014e
            android.widget.TextView r2 = r3.sentmessage
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            int r6 = r6.getColor(r13)
            r2.setTextColor(r6)
            android.widget.TextView r2 = r3.senttime
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            int r6 = r6.getColor(r10)
            r2.setTextColor(r6)
            goto L_0x0176
        L_0x014e:
            android.widget.TextView r2 = r3.sentmessage
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            r8 = 2131034145(0x7f050021, float:1.76788E38)
            int r6 = r6.getColor(r8)
            r2.setTextColor(r6)
            android.widget.TextView r2 = r3.senttime
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            r8 = 2131034227(0x7f050073, float:1.7678966E38)
            int r6 = r6.getColor(r8)
            r2.setTextColor(r6)
        L_0x0176:
            int r2 = triggeredposition
            if (r2 != r1) goto L_0x01aa
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            android.content.Context r6 = r0.context
            android.content.res.Resources r6 = r6.getResources()
            r8 = 2131165282(0x7f070062, float:1.7944777E38)
            android.graphics.drawable.Drawable r6 = r6.getDrawable(r8)
            r2.setForeground(r6)
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            android.graphics.drawable.Drawable r2 = r2.getForeground()
            r6 = 2
            int[] r6 = new int[r6]
            r6 = {255, 0} // fill-array
            android.animation.ObjectAnimator r2 = android.animation.ObjectAnimator.ofInt(r2, r12, r6)
            r8 = 1500(0x5dc, double:7.41E-321)
            android.animation.ObjectAnimator r6 = r2.setDuration(r8)
            r8 = 100
            r6.setStartDelay(r8)
            r2.start()
        L_0x01aa:
            java.util.List<java.lang.String> r2 = r0.indexes
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            r6.append(r1)
            r6.append(r4)
            java.lang.String r4 = r6.toString()
            boolean r2 = r2.contains(r4)
            if (r2 != 0) goto L_0x01cd
            int r2 = triggeredposition
            if (r2 != r1) goto L_0x01c6
            goto L_0x01cd
        L_0x01c6:
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            r4 = 0
            r2.setForeground(r4)
            goto L_0x01e3
        L_0x01cd:
            int r2 = triggeredposition
            if (r2 == r1) goto L_0x01e3
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            android.content.Context r4 = r0.context
            android.content.res.Resources r4 = r4.getResources()
            r6 = 2131165282(0x7f070062, float:1.7944777E38)
            android.graphics.drawable.Drawable r4 = r4.getDrawable(r6)
            r2.setForeground(r4)
        L_0x01e3:
            java.util.List<java.lang.String> r2 = r0.searchedIndexes
            java.lang.String r1 = java.lang.String.valueOf(r19)
            boolean r1 = r2.contains(r1)
            if (r1 == 0) goto L_0x0227
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r15)
            java.lang.String r2 = r0.searchedword
            r1.append(r2)
            r1.append(r14)
            java.lang.String r1 = r1.toString()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r8 = r16
            r2.append(r8)
            java.lang.String r4 = r0.searchedword
            java.lang.String r4 = java.util.regex.Pattern.quote(r4)
            r2.append(r4)
            java.lang.String r2 = r2.toString()
            java.lang.String r1 = r5.replaceAll(r2, r1)
            android.widget.TextView r2 = r3.sentmessage
            android.text.Spanned r1 = android.text.Html.fromHtml(r1, r7)
            r2.setText(r1)
        L_0x0227:
            android.widget.LinearLayout r1 = r3.fullbackgroundlayout
            com.vinaykpro.whatsviewer.Adapter$17 r2 = new com.vinaykpro.whatsviewer.Adapter$17
            r2.<init>(r3)
            r1.setOnClickListener(r2)
            android.widget.LinearLayout r1 = r3.fullbackgroundlayout
            com.vinaykpro.whatsviewer.Adapter$18 r2 = new com.vinaykpro.whatsviewer.Adapter$18
            r2.<init>(r3)
            r1.setOnLongClickListener(r2)
            goto L_0x0442
        L_0x023d:
            r8 = r16
            int r3 = r0.getItemViewType(r1)
            r10 = 1
            if (r3 != r10) goto L_0x040f
            r3 = r18
            com.vinaykpro.whatsviewer.RecievedViewHolder r3 = (com.vinaykpro.whatsviewer.RecievedViewHolder) r3
            android.widget.TextView r9 = r3.recievedmessage
            r9.setText(r5)
            android.widget.TextView r9 = r3.recievedtime
            r9.setText(r2)
            boolean r2 = r0.isthisagroup
            if (r2 == 0) goto L_0x0292
            android.widget.TextView r2 = r3.recievername
            r2.setVisibility(r7)
            android.widget.TextView r2 = r3.recievername
            java.util.List<java.lang.String> r9 = r0.messageList
            java.lang.Object r9 = r9.get(r1)
            java.lang.String r9 = (java.lang.String) r9
            java.lang.String r9 = r0.getName(r9)
            r2.setText(r9)
            java.util.List<java.lang.String> r2 = r0.messageList
            java.lang.Object r2 = r2.get(r1)
            java.lang.String r2 = (java.lang.String) r2
            java.lang.String r2 = r0.getName(r2)
            android.widget.TextView r9 = r3.recievername
            java.util.List<java.lang.String> r10 = r0.colorList
            java.util.List<java.lang.String> r13 = r0.groupmemebernames
            int r13 = r13.indexOf(r2)
            java.lang.Object r10 = r10.get(r13)
            java.lang.String r10 = (java.lang.String) r10
            int r10 = android.graphics.Color.parseColor(r10)
            r9.setTextColor(r10)
            goto L_0x0299
        L_0x0292:
            android.widget.TextView r2 = r3.recievername
            r2.setVisibility(r11)
            java.lang.String r2 = r0.userName2
        L_0x0299:
            r9 = 2131165280(0x7f070060, float:1.7944773E38)
            if (r1 == 0) goto L_0x02e9
            java.util.List<java.lang.String> r10 = r0.messageList
            int r13 = r1 + -1
            java.lang.Object r10 = r10.get(r13)
            java.lang.String r10 = (java.lang.String) r10
            boolean r10 = r0.canigetName(r10)
            if (r10 == 0) goto L_0x02e9
            java.util.List<java.lang.String> r10 = r0.messageList
            java.lang.Object r10 = r10.get(r13)
            java.lang.String r10 = (java.lang.String) r10
            java.lang.String r10 = r0.getName(r10)
            java.util.Objects.requireNonNull(r10)
            java.lang.String r10 = (java.lang.String) r10
            boolean r2 = r10.equals(r2)
            if (r2 != 0) goto L_0x02d3
            r6.setMargins(r7, r11, r7, r7)
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            r2.setLayoutParams(r6)
            androidx.constraintlayout.widget.ConstraintLayout r2 = r3.recieverLayout
            r2.setBackgroundResource(r9)
            goto L_0x02f6
        L_0x02d3:
            android.widget.TextView r2 = r3.recievername
            r2.setVisibility(r11)
            r6.setMargins(r7, r7, r7, r7)
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            r2.setLayoutParams(r6)
            androidx.constraintlayout.widget.ConstraintLayout r2 = r3.recieverLayout
            r6 = 2131165281(0x7f070061, float:1.7944775E38)
            r2.setBackgroundResource(r6)
            goto L_0x02f6
        L_0x02e9:
            r6.setMargins(r7, r11, r7, r7)
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            r2.setLayoutParams(r6)
            androidx.constraintlayout.widget.ConstraintLayout r2 = r3.recieverLayout
            r2.setBackgroundResource(r9)
        L_0x02f6:
            boolean r2 = r0.isNightMode
            if (r2 == 0) goto L_0x0323
            android.widget.TextView r2 = r3.recievedmessage
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            r9 = 2131034738(0x7f050272, float:1.7680002E38)
            int r6 = r6.getColor(r9)
            r2.setTextColor(r6)
            android.widget.TextView r2 = r3.recievedtime
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            r9 = 2131034228(0x7f050074, float:1.7678968E38)
            int r6 = r6.getColor(r9)
            r2.setTextColor(r6)
            goto L_0x034b
        L_0x0323:
            android.widget.TextView r2 = r3.recievedmessage
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            r9 = 2131034145(0x7f050021, float:1.76788E38)
            int r6 = r6.getColor(r9)
            r2.setTextColor(r6)
            android.widget.TextView r2 = r3.recievedtime
            android.content.Context r6 = r0.context
            com.vinaykpro.whatsviewer.MainActivity r6 = (com.vinaykpro.whatsviewer.MainActivity) r6
            android.content.res.Resources r6 = r6.getResources()
            r9 = 2131034227(0x7f050073, float:1.7678966E38)
            int r6 = r6.getColor(r9)
            r2.setTextColor(r6)
        L_0x034b:
            int r2 = triggeredposition
            if (r2 != r1) goto L_0x037f
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            android.content.Context r6 = r0.context
            android.content.res.Resources r6 = r6.getResources()
            r9 = 2131165282(0x7f070062, float:1.7944777E38)
            android.graphics.drawable.Drawable r6 = r6.getDrawable(r9)
            r2.setForeground(r6)
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            android.graphics.drawable.Drawable r2 = r2.getForeground()
            r6 = 2
            int[] r6 = new int[r6]
            r6 = {255, 0} // fill-array
            android.animation.ObjectAnimator r2 = android.animation.ObjectAnimator.ofInt(r2, r12, r6)
            r9 = 1500(0x5dc, double:7.41E-321)
            android.animation.ObjectAnimator r6 = r2.setDuration(r9)
            r9 = 100
            r6.setStartDelay(r9)
            r2.start()
        L_0x037f:
            java.util.List<java.lang.String> r2 = r0.indexes
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            r6.append(r1)
            r6.append(r4)
            java.lang.String r4 = r6.toString()
            boolean r2 = r2.contains(r4)
            if (r2 != 0) goto L_0x03a2
            int r2 = triggeredposition
            if (r2 != r1) goto L_0x039b
            goto L_0x03a2
        L_0x039b:
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            r4 = 0
            r2.setForeground(r4)
            goto L_0x03b8
        L_0x03a2:
            int r2 = triggeredposition
            if (r2 == r1) goto L_0x03b8
            android.widget.LinearLayout r2 = r3.fullbackgroundlayout
            android.content.Context r4 = r0.context
            android.content.res.Resources r4 = r4.getResources()
            r6 = 2131165282(0x7f070062, float:1.7944777E38)
            android.graphics.drawable.Drawable r4 = r4.getDrawable(r6)
            r2.setForeground(r4)
        L_0x03b8:
            java.util.List<java.lang.String> r2 = r0.searchedIndexes
            java.lang.String r1 = java.lang.String.valueOf(r19)
            boolean r1 = r2.contains(r1)
            if (r1 == 0) goto L_0x03fa
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r15)
            java.lang.String r2 = r0.searchedword
            r1.append(r2)
            r1.append(r14)
            java.lang.String r1 = r1.toString()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r8)
            java.lang.String r4 = r0.searchedword
            java.lang.String r4 = java.util.regex.Pattern.quote(r4)
            r2.append(r4)
            java.lang.String r2 = r2.toString()
            java.lang.String r1 = r5.replaceAll(r2, r1)
            android.widget.TextView r2 = r3.recievedmessage
            android.text.Spanned r1 = android.text.Html.fromHtml(r1, r7)
            r2.setText(r1)
        L_0x03fa:
            android.widget.LinearLayout r1 = r3.fullbackgroundlayout
            com.vinaykpro.whatsviewer.Adapter$19 r2 = new com.vinaykpro.whatsviewer.Adapter$19
            r2.<init>(r3)
            r1.setOnClickListener(r2)
            android.widget.LinearLayout r1 = r3.fullbackgroundlayout
            com.vinaykpro.whatsviewer.Adapter$20 r2 = new com.vinaykpro.whatsviewer.Adapter$20
            r2.<init>(r3)
            r1.setOnLongClickListener(r2)
            goto L_0x0442
        L_0x040f:
            r2 = r18
            com.vinaykpro.whatsviewer.NoteViewHolder r2 = (com.vinaykpro.whatsviewer.NoteViewHolder) r2
            android.widget.TextView r3 = r2.note
            java.util.List<java.lang.String> r4 = r0.messageList
            java.lang.Object r4 = r4.get(r1)
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            r3.setText(r4)
            java.util.List<java.lang.String> r3 = r0.messageList
            java.lang.Object r3 = r3.get(r1)
            java.lang.String r3 = (java.lang.String) r3
            boolean r3 = r3.contains(r9)
            if (r3 == 0) goto L_0x043a
            r3 = 1
            if (r1 != r3) goto L_0x043a
            android.widget.TextView r1 = r2.note
            r2 = 2131165322(0x7f07008a, float:1.7944858E38)
            r1.setBackgroundResource(r2)
            goto L_0x0442
        L_0x043a:
            android.widget.TextView r1 = r2.note
            r2 = 2131165314(0x7f070082, float:1.7944842E38)
            r1.setBackgroundResource(r2)
        L_0x0442:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vinaykpro.whatsviewer.Adapter.onBindViewHolder(androidx.recyclerview.widget.RecyclerView$ViewHolder, int):void");
    }

    public int getItemCount() {
        return this.messageList.size();
    }

    public void deletefromtable(List<String> list) {
        new MySqllite(this.context).deletemessagefromtable(this.tablename, list);
        list.clear();
    }

    public void updatemessage(String str, String str2) {
        new MySqllite(this.context).updatemessage(this.tablename, str, str2);
    }

    public boolean getNightMode() {
        return ((MainActivity) this.context).getSharedPreferences("SP", 0).getBoolean("darkMode", false);
    }
}
