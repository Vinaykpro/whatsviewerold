package com.vinaykpro.whatsviewer;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class HomeFragmentAdapter extends FragmentStateAdapter {
    public int getItemCount() {
        return 3;
    }

    public HomeFragmentAdapter(FragmentManager fragmentManager, Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    public Fragment createFragment(int i) {
        if (i == 1) {
            return new StatusFragment();
        }
        if (i != 2) {
            return new ChatsFragment();
        }
        return new CallsFragment();
    }
}
