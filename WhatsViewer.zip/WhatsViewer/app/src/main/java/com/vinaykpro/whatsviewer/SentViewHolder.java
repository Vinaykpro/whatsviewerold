package com.vinaykpro.whatsviewer;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

/* compiled from: Adapter */
class SentViewHolder extends RecyclerView.ViewHolder {
    LinearLayout fullbackgroundlayout;
    boolean isselected = false;
    ImFlexboxLayout senderLayout;
    TextView sentmessage;
    TextView senttime;
    ImageView ticks;

    public SentViewHolder(View view) {
        super(view);
        this.senderLayout = (ImFlexboxLayout) view.findViewById(C1092R.C1095id.sender_bg_layout);
        this.fullbackgroundlayout = (LinearLayout) view.findViewById(C1092R.C1095id.senderlayoutfull);
        this.sentmessage = (TextView) view.findViewById(C1092R.C1095id.recievedmessage);
        this.senttime = (TextView) view.findViewById(C1092R.C1095id.recievedtime);
        this.ticks = (ImageView) view.findViewById(C1092R.C1095id.ticks);
    }
}
