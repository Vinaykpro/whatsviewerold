package com.vinaykpro.whatsviewer;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Objects;

public class ProfileActivity extends AppCompatActivity {

    /* renamed from: dp */
    public static Uri f173dp;
    ImageView backbtn;
    TextView blockname;
    MySqllite database;
    ActivityResultLauncher<Intent> mediaOpener = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        public void onActivityResult(ActivityResult activityResult) {
            Bitmap decodeBitmap;
            if (activityResult.getResultCode() == -1) {
                Intent data = activityResult.getData();
                Objects.requireNonNull(data);
                Uri data2 = data.getData();
                Bitmap bitmap = null;
                ContentResolver contentResolver = ProfileActivity.this.getContentResolver();
                try {
                    if (Build.VERSION.SDK_INT < 28) {
                        decodeBitmap = MediaStore.Images.Media.getBitmap(contentResolver, data2);
                    } else {
                        decodeBitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, data2));
                    }
                    bitmap = decodeBitmap;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    File cacheDir = ProfileActivity.this.getApplicationContext().getCacheDir();
                    FileOutputStream fileOutputStream = new FileOutputStream(new File(cacheDir, ProfileActivity.this.tablename + "dp.png"));
                    bitmap.compress(Bitmap.CompressFormat.PNG, 50, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (Exception e2) {
                    e2.printStackTrace();
                    ProfileActivity profileActivity = ProfileActivity.this;
                    Toast.makeText(profileActivity, e2 + "", 0).show();
                }
                ProfileActivity.this.profilepic.setImageBitmap(bitmap);
            }
        }
    });
    EditText name;
    EditText number;
    EditText onlinestatus;
    ImageView profilepic;
    TextView reportname;
    String sname;
    String sonlinestatus;
    String tablename;
    int usercount;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C1092R.layout.activity_profile);
        ActionBar supportActionBar = getSupportActionBar();
        Objects.requireNonNull(supportActionBar);
        supportActionBar.hide();
        this.database = new MySqllite(this);
        this.profilepic = (ImageView) findViewById(C1092R.C1095id.profile);
        this.name = (EditText) findViewById(C1092R.C1095id.name);
        this.number = (EditText) findViewById(C1092R.C1095id.number);
        this.onlinestatus = (EditText) findViewById(C1092R.C1095id.textView10);
        this.blockname = (TextView) findViewById(C1092R.C1095id.blockname);
        this.reportname = (TextView) findViewById(C1092R.C1095id.reportname);
        this.backbtn = (ImageView) findViewById(C1092R.C1095id.imageView18);
        Bundle extras = getIntent().getExtras();
        this.tablename = extras.getString("tablename");
        this.sname = extras.getString("username");
        this.sonlinestatus = extras.getString("lastseen");
        this.usercount = extras.getInt("usercount");
        this.backbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ProfileActivity.this.finish();
            }
        });
        try {
            File file = new File(getApplicationContext().getCacheDir() + "/" + this.tablename + "dp.png");
            if (file.exists()) {
                this.profilepic.setImageURI(Uri.fromFile(file));
            } else if (this.usercount > 2) {
                this.profilepic.setImageResource(C1092R.C1094drawable.groupdefaultdp);
            } else {
                this.profilepic.setImageResource(C1092R.C1094drawable.userdefaultdp);
            }
        } catch (Exception e) {
            Toast.makeText(this, e + "", 0).show();
        }
        this.name.setText(this.sname);
        this.onlinestatus.setText(this.sonlinestatus);
        TextView textView = this.blockname;
        textView.setText("Block " + this.sname);
        TextView textView2 = this.reportname;
        textView2.setText("Report " + this.sname);
        this.profilepic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setType("image/*");
                ProfileActivity.this.mediaOpener.launch(intent);
            }
        });
        this.profilepic.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                File file = new File(ProfileActivity.this.getApplicationContext().getCacheDir() + "/" + ProfileActivity.this.tablename + "dp.png");
                if (!file.exists()) {
                    return true;
                }
                file.delete();
                ProfileActivity.this.profilepic.setImageResource(C1092R.C1094drawable.userdefaultdp);
                Toast.makeText(ProfileActivity.this, "Profile Picture Removed Successfully", 0).show();
                return true;
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();
        this.database.updatechatname(this.tablename, this.name.getText().toString());
        this.database.updatelastseen(this.tablename, this.onlinestatus.getText().toString());
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        this.database.updatechatname(this.tablename, this.name.getText().toString());
        this.database.updatelastseen(this.tablename, this.onlinestatus.getText().toString());
        super.onPause();
    }
}
