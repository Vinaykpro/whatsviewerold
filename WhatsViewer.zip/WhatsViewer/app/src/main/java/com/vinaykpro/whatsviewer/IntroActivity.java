package com.vinaykpro.whatsviewer;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Objects;

public class IntroActivity extends AppCompatActivity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        ActionBar supportActionBar = getSupportActionBar();
        Objects.requireNonNull(supportActionBar);
        supportActionBar.hide();
        super.onCreate(bundle);
        setContentView((int) C1092R.layout.activity_intro);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                IntroActivity.this.startActivity(new Intent(IntroActivity.this, HomeActivity.class));
                IntroActivity.this.finish();
            }
        }, 1000);
    }
}
