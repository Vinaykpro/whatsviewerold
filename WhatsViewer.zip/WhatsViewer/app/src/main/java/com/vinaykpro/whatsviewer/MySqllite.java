package com.vinaykpro.whatsviewer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import java.util.ArrayList;
import java.util.List;

public class MySqllite extends SQLiteOpenHelper {
    private static final String DB_NAME = "vkwhatsviewerdb";

    public MySqllite(Context context) {
        super(context, DB_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("create table hometable(id INTEGER PRIMARY KEY, name text, tablename text, firstname text, secondname text, sendername text, usercount integer, lastseen text,lastmessage text, lastmessagetime text, uri text, messageindex integer, blueticks integer)");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS hometable");
        onCreate(sQLiteDatabase);
    }

    public boolean addText(String str, String str2, String str3, String str4, String str5, int i, String str6, String str7, String str8, Uri uri, int i2, int i3) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(AppMeasurementSdk.ConditionalUserProperty.NAME, str);
        contentValues.put("tablename", str2);
        contentValues.put("firstname", str3);
        contentValues.put("secondname", str4);
        contentValues.put("sendername", str5);
        contentValues.put("usercount", Integer.valueOf(i));
        contentValues.put("lastseen", str6);
        contentValues.put("lastmessage", str7);
        contentValues.put("lastmessagetime", str8);
        contentValues.put("uri", "noimage");
        contentValues.put("messageindex", Integer.valueOf(i2));
        contentValues.put("blueticks", Integer.valueOf(i3));
        return writableDatabase.insertOrThrow("hometable", (String) null, contentValues) != -1;
    }

    public List<Contact> getAllText() {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        ArrayList arrayList = new ArrayList();
        Cursor rawQuery = readableDatabase.rawQuery("select * from hometable", (String[]) null);
        rawQuery.moveToFirst();
        while (!rawQuery.isAfterLast()) {
            String string = rawQuery.getString(rawQuery.getColumnIndex(AppMeasurementSdk.ConditionalUserProperty.NAME));
            String string2 = rawQuery.getString(rawQuery.getColumnIndex("tablename"));
            String string3 = rawQuery.getString(rawQuery.getColumnIndex("firstname"));
            String string4 = rawQuery.getString(rawQuery.getColumnIndex("secondname"));
            String string5 = rawQuery.getString(rawQuery.getColumnIndex("sendername"));
            String string6 = rawQuery.getString(rawQuery.getColumnIndex("lastseen"));
            int parseInt = Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("usercount")));
            String string7 = rawQuery.getString(rawQuery.getColumnIndex("lastmessage"));
            String string8 = rawQuery.getString(rawQuery.getColumnIndex("lastmessagetime"));
            int parseInt2 = Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("blueticks")));
            Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("messageindex")));
            arrayList.add(new Contact(string, string2, string3, string4, string5, parseInt, string6, string7, string8, (Uri) null, 0, parseInt2));
            rawQuery.moveToNext();
        }
        rawQuery.close();
        return arrayList;
    }

    public void addChatToContact(String str, List<String> list) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("create table " + str + "(id INTEGER PRIMARY KEY, str text)");
        for (String put : list) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("str", put);
            writableDatabase.insert(str, (String) null, contentValues);
        }
    }

    public List<String> getChatData(String str) {
        ArrayList arrayList = new ArrayList();
        if (isTableExists(str)) {
            SQLiteDatabase readableDatabase = getReadableDatabase();
            Cursor rawQuery = readableDatabase.rawQuery("select * from " + str, (String[]) null);
            rawQuery.moveToFirst();
            while (!rawQuery.isAfterLast()) {
                arrayList.add(rawQuery.getString(rawQuery.getColumnIndex("str")));
                rawQuery.moveToNext();
            }
            rawQuery.close();
        }
        return arrayList;
    }

    public boolean isTableExists(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = '" + str + "'", (String[]) null);
        if (rawQuery != null) {
            try {
                if (rawQuery.getCount() > 0) {
                    if (rawQuery != null) {
                        rawQuery.close();
                    }
                    return true;
                }
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        }
        if (rawQuery != null) {
            rawQuery.close();
        }
        return false;
        throw th;
    }

    public void deletemessagefromtable(String str, List<String> list) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        for (String str2 : list) {
            writableDatabase.execSQL("DELETE from " + str + " where str='" + str2 + "'");
        }
    }

    public void updatemessage(String str, String str2, String str3) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE " + str + " SET str='" + str3 + "' WHERE str='" + str2 + "'");
    }

    public void updatechatname(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET name='" + str2 + "' WHERE tablename='" + str + "'");
    }

    public void updatefirstname(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET firstname='" + str2 + "' WHERE tablename='" + str + "'");
    }

    public void updatesecondname(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET secondname='" + str2 + "' WHERE tablename='" + str + "'");
    }

    public void updatelastseen(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET lastseen='" + str2 + "' WHERE tablename='" + str + "'");
    }

    public void updatelastmessage(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET lastmessage='" + str2 + "' WHERE tablename='" + str + "'");
    }

    public void updatelastmessagetime(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET lastmessagetime='" + str2 + "' WHERE tablename='" + str + "'");
    }

    public void updatemessageindex(String str, int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET messageindex=" + i + " WHERE tablename='" + str + "'");
    }

    public int getusercount(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("SELECT usercount FROM hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        int i = 2;
        while (!rawQuery.isAfterLast()) {
            i = Integer.parseInt(rawQuery.getString(rawQuery.getColumnIndex("usercount")));
            rawQuery.moveToNext();
        }
        rawQuery.close();
        return i;
    }

    public List<String> getUserNames(String str) {
        ArrayList arrayList = new ArrayList();
        Cursor rawQuery = getReadableDatabase().rawQuery("select secondname from hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        for (String add : rawQuery.getString(rawQuery.getColumnIndex("secondname")).split("\\R")) {
            arrayList.add(add);
        }
        return arrayList;
    }

    public void deleteChat(String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("DROP TABLE " + str + "");
        writableDatabase.execSQL("DELETE FROM hometable WHERE tablename='" + str + "'");
    }

    public void updateProfilePicture(String str, Uri uri) {
        String uri2 = uri.toString();
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET uri='" + uri2 + "' WHERE tablename='" + str + "'");
    }

    public Uri getProfilePicture(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("select uri from hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        String string = rawQuery.getString(rawQuery.getColumnIndex("uri"));
        rawQuery.close();
        if (string.equals("noimage")) {
            return null;
        }
        return Uri.parse(string);
    }

    public String getlastseen(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("select lastseen from hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        String string = rawQuery.getString(rawQuery.getColumnIndex("lastseen"));
        rawQuery.close();
        return string;
    }

    public String getname(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("select name from hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        String string = rawQuery.getString(rawQuery.getColumnIndex(AppMeasurementSdk.ConditionalUserProperty.NAME));
        rawQuery.close();
        return string;
    }

    public void updatelastleftmessageindex(String str, int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET messageindex=" + i + " WHERE tablename='" + str + "'");
    }

    public int getlastleftmessageindex(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("select messageindex from hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        int i = rawQuery.getInt(rawQuery.getColumnIndex("messageindex"));
        rawQuery.close();
        return i;
    }

    public void updateblueticks(String str, int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("UPDATE hometable SET blueticks=" + i + " WHERE tablename='" + str + "'");
    }

    public int getblueticks(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("select blueticks from hometable WHERE tablename = '" + str + "'", (String[]) null);
        rawQuery.moveToFirst();
        int i = rawQuery.getInt(rawQuery.getColumnIndex("blueticks"));
        rawQuery.close();
        return i;
    }
}
