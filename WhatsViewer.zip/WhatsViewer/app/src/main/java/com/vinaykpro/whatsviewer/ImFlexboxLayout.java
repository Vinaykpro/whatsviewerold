package com.vinaykpro.whatsviewer;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;

public class ImFlexboxLayout extends RelativeLayout {

    /* renamed from: a */
    private TypedArray f171a;
    private TextView viewPartMain;
    private int viewPartMainHeight;
    private RelativeLayout.LayoutParams viewPartMainLayoutParams;
    private int viewPartMainWidth;
    private View viewPartSlave;
    private int viewPartSlaveHeight;
    private RelativeLayout.LayoutParams viewPartSlaveLayoutParams;
    private int viewPartSlaveWidth;

    public ImFlexboxLayout(Context context) {
        super(context);
    }

    public ImFlexboxLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f171a = context.obtainStyledAttributes(attributeSet, C1092R.styleable.ImFlexboxLayout, 0, 0);
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        try {
            this.viewPartMain = (TextView) findViewById(this.f171a.getResourceId(0, -1));
            this.viewPartSlave = findViewById(this.f171a.getResourceId(1, -1));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        super.onMeasure(i, i2);
        int size = View.MeasureSpec.getSize(i);
        View.MeasureSpec.getSize(i2);
        if (this.viewPartMain != null && this.viewPartSlave != null && size > 0) {
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            getPaddingTop();
            getPaddingBottom();
            this.viewPartMainLayoutParams = (RelativeLayout.LayoutParams) this.viewPartMain.getLayoutParams();
            this.viewPartMainWidth = this.viewPartMain.getMeasuredWidth() + this.viewPartMainLayoutParams.leftMargin + this.viewPartMainLayoutParams.rightMargin;
            this.viewPartMainHeight = this.viewPartMain.getMeasuredHeight() + this.viewPartMainLayoutParams.topMargin + this.viewPartMainLayoutParams.bottomMargin;
            this.viewPartSlaveLayoutParams = (RelativeLayout.LayoutParams) this.viewPartSlave.getLayoutParams();
            this.viewPartSlaveWidth = this.viewPartSlave.getMeasuredWidth() + this.viewPartSlaveLayoutParams.leftMargin + this.viewPartSlaveLayoutParams.rightMargin;
            this.viewPartSlaveHeight = this.viewPartSlave.getMeasuredHeight() + this.viewPartSlaveLayoutParams.topMargin + this.viewPartSlaveLayoutParams.bottomMargin;
            int lineCount = this.viewPartMain.getLineCount();
            float lineWidth = lineCount > 0 ? this.viewPartMain.getLayout().getLineWidth(lineCount - 1) : 0.0f;
            int paddingLeft2 = getPaddingLeft() + getPaddingRight() + 2;
            int paddingTop = getPaddingTop() + getPaddingBottom();
            if (lineCount <= 1 || ((float) this.viewPartSlaveWidth) + lineWidth >= ((float) this.viewPartMain.getMeasuredWidth())) {
                if (lineCount > 1 && lineWidth + ((float) this.viewPartSlaveWidth) >= ((float) paddingLeft)) {
                    i3 = paddingLeft2 + this.viewPartMainWidth;
                    i5 = this.viewPartMainHeight;
                    i6 = this.viewPartSlaveHeight;
                } else if (lineCount != 1 || this.viewPartMainWidth + this.viewPartSlaveWidth < paddingLeft) {
                    i3 = paddingLeft2 + this.viewPartMainWidth + this.viewPartSlaveWidth;
                    i4 = this.viewPartMainHeight;
                } else {
                    i3 = paddingLeft2 + this.viewPartMain.getMeasuredWidth();
                    i5 = this.viewPartMainHeight;
                    i6 = this.viewPartSlaveHeight;
                }
                i4 = i5 + i6;
            } else {
                i3 = paddingLeft2 + this.viewPartMainWidth;
                i4 = this.viewPartMainHeight;
            }
            int i7 = paddingTop + i4;
            setMeasuredDimension(i3, i7);
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(i3, BasicMeasure.EXACTLY), View.MeasureSpec.makeMeasureSpec(i7, BasicMeasure.EXACTLY));
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        TextView textView = this.viewPartMain;
        if (textView != null && this.viewPartSlave != null) {
            textView.layout(getPaddingLeft(), getPaddingTop(), this.viewPartMain.getWidth() + getPaddingLeft(), this.viewPartMain.getHeight() + getPaddingTop());
            int i5 = i3 - i;
            int i6 = i4 - i2;
            this.viewPartSlave.layout((i5 - this.viewPartSlaveWidth) - getPaddingRight(), (i6 - getPaddingBottom()) - this.viewPartSlaveHeight, i5 - getPaddingRight(), i6 - getPaddingBottom());
        }
    }
}
