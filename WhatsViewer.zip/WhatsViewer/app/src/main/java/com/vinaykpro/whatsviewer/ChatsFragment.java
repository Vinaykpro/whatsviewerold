package com.vinaykpro.whatsviewer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ChatsFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    ChatsFragmentAdapter adapter;
    private String mParam1;
    private String mParam2;
    List<Contact> messageList;
    RecyclerView recyclerView;
    MySqllite sqllite;

    public void onViewCreated(View view, Bundle bundle) {
    }

    public static ChatsFragment newInstance(String str, String str2) {
        ChatsFragment chatsFragment = new ChatsFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        chatsFragment.setArguments(bundle);
        return chatsFragment;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            this.mParam1 = getArguments().getString(ARG_PARAM1);
            this.mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(C1092R.layout.fragment_chats, viewGroup, false);
        RecyclerView recyclerView2 = (RecyclerView) inflate.findViewById(C1092R.C1095id.chatsRecyclerView);
        this.recyclerView = recyclerView2;
        recyclerView2.setLayoutManager(new LinearLayoutManager(getContext()));
        this.messageList = new ArrayList();
        MySqllite mySqllite = new MySqllite(getContext());
        this.sqllite = mySqllite;
        this.messageList = mySqllite.getAllText();
        ChatsFragmentAdapter chatsFragmentAdapter = new ChatsFragmentAdapter(this.messageList, getContext());
        this.adapter = chatsFragmentAdapter;
        this.recyclerView.setAdapter(chatsFragmentAdapter);
        this.adapter.notifyDataSetChanged();
        return inflate;
    }

    public void onResume() {
        this.messageList = this.sqllite.getAllText();
        ChatsFragmentAdapter chatsFragmentAdapter = new ChatsFragmentAdapter(this.messageList, getContext());
        this.adapter = chatsFragmentAdapter;
        this.recyclerView.setAdapter(chatsFragmentAdapter);
        this.adapter.notifyDataSetChanged();
        super.onResume();
    }

    public void refresh() {
        this.messageList = this.sqllite.getAllText();
        ChatsFragmentAdapter chatsFragmentAdapter = new ChatsFragmentAdapter(this.messageList, getContext());
        this.adapter = chatsFragmentAdapter;
        this.recyclerView.setAdapter(chatsFragmentAdapter);
        this.adapter.notifyDataSetChanged();
    }
}
