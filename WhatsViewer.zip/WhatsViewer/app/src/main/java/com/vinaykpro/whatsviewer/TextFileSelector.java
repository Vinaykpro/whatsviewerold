package com.vinaykpro.whatsviewer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Objects;

public class TextFileSelector extends AppCompatActivity {
    Button chooseBtn;
    TextView recieverName;
    TextView senderName;
    ImageView swapButton;
    ActivityResultLauncher<Intent> textFileOpener = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        public void onActivityResult(ActivityResult activityResult) {
            String str;
            if (activityResult.getResultCode() == -1) {
                Uri data = activityResult.getData().getData();
                new File(data.toString());
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(TextFileSelector.this.getContentResolver().openInputStream(data)));
                    int i = 1;
                    str = "";
                    while (i <= 2) {
                        i++;
                        try {
                            str = str + bufferedReader.readLine() + "\n\n\n";
                        } catch (Exception e) {
                            e = e;
                            e.printStackTrace();
                            Toast.makeText(TextFileSelector.this, e + "", 0).show();
                            Toast.makeText(TextFileSelector.this, str, 0).show();
                        }
                    }
                } catch (Exception e2) {
                    e = e2;
                    str = "";
                    e.printStackTrace();
                    Toast.makeText(TextFileSelector.this, e + "", 0).show();
                    Toast.makeText(TextFileSelector.this, str, 0).show();
                }
                Toast.makeText(TextFileSelector.this, str, 0).show();
            }
        }
    });

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C1092R.layout.activity_text_file_selector);
        ActionBar supportActionBar = getSupportActionBar();
        Objects.requireNonNull(supportActionBar);
        supportActionBar.hide();
        this.chooseBtn = (Button) findViewById(C1092R.C1095id.choose_btn);
        this.swapButton = (ImageView) findViewById(C1092R.C1095id.swap_names_btn);
        this.senderName = (TextView) findViewById(C1092R.C1095id.sender_name);
        this.recieverName = (TextView) findViewById(C1092R.C1095id.reciever_name);
        this.chooseBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                TextFileSelector.this.textFileOpener.launch(new Intent().setType("text/plain").setAction("android.intent.action.GET_CONTENT"));
            }
        });
    }
}
