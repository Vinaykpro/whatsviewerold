package com.vinaykpro.whatsviewer;

import android.net.Uri;

public class Contact {
    int blueticks;
    String firstname;
    Uri imageuri = null;
    String lastmessage;
    String lastmessagetime;
    String lastname;
    String lastseen;
    int messageindex;
    String name;
    String sendername;
    String tablename;
    int usercount;

    public Contact(String str, String str2, String str3, String str4, String str5, int i, String str6, String str7, String str8, Uri uri, int i2, int i3) {
        this.name = str;
        this.tablename = str2;
        this.lastseen = str6;
        this.sendername = str5;
        this.usercount = i;
        this.lastmessage = str7;
        this.lastmessagetime = str8;
        this.imageuri = uri;
        this.messageindex = i2;
        this.firstname = str3;
        this.lastname = str4;
        this.blueticks = i3;
    }

    public String getName() {
        return this.name;
    }

    public String getTablename() {
        return this.tablename;
    }

    public String getFirstname() {
        return this.firstname;
    }

    public String getLastname() {
        return this.lastname;
    }

    public String getSendername() {
        return this.sendername;
    }

    public int getUsercount() {
        return this.usercount;
    }

    public String getLastseen() {
        return this.lastseen;
    }

    public String getLastmessage() {
        return this.lastmessage;
    }

    public String getLastmessagetime() {
        return this.lastmessagetime;
    }

    public Uri getImageuri() {
        return this.imageuri;
    }

    public int getMessageindex() {
        return this.messageindex;
    }

    public int getBlueticks() {
        return this.blueticks;
    }
}
