package com.vinaykpro.whatsviewer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import java.io.File;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HomeActivity extends AppCompatActivity {
    public static boolean isfilevalid = false;
    public static List<String> messageList = new ArrayList();
    public static List<String> names;
    int STORAGE_READ_PERMISSION_CODE = 102;
    int STORAGE_WRITE_PERMISSION_CODE = 103;
    HomeFragmentAdapter adapter;
    FloatingActionButton addtextfilebutton;
    public boolean changedatestillnow = false;
    Intent data;
    public String date = "";

    /* renamed from: f */
    File f168f;
    String firstName;

    /* renamed from: fm */
    FragmentManager f169fm;
    public boolean isInNightMode = false;
    public boolean ischataddedandreadytolaunch = false;
    public boolean isintentfresh = true;
    public boolean isinterstitialadfinished = false;
    public boolean istemp0available = false;
    public boolean istempavailable = false;
    ConstraintLayout loadinglayout;
    AdView mAdView;
    /* access modifiers changed from: private */
    public InterstitialAd mInterstitialAd;
    String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    public List<String> readabledates;
    String secondName = "";

    /* renamed from: ss */
    String f170ss = "";
    TabLayout tabLayout;
    String tablename;
    public String temp = "";
    public String temp0 = "";
    ActivityResultLauncher<Intent> textFileOpener = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        public void onActivityResult(ActivityResult activityResult) {
            if (activityResult.getResultCode() == -1) {
                HomeActivity.this.data = activityResult.getData();
                HomeActivity homeActivity = HomeActivity.this;
                homeActivity.uri = homeActivity.data.getData();
                HomeActivity homeActivity2 = HomeActivity.this;
                homeActivity2.checkNopen(homeActivity2.uri);
                HomeActivity.this.loadInterstitialAd();
            }
        }
    });
    Uri uri;
    public boolean useseconddateformat = false;
    ViewPager2 viewPager2;

    /* access modifiers changed from: private */
    public void prompt() {
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(C1092R.C1097menu.home_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C1092R.C1095id.clear_all) {
            Toast.makeText(this, "Please give your feedback about this app in the Google Play Store", 0).show();
        } else if (itemId == C1092R.C1095id.switch_modes) {
            SharedPreferences.Editor edit = getSharedPreferences("SP", 0).edit();
            if (this.isInNightMode) {
                edit.putBoolean("darkMode", false);
                edit.apply();
                AppCompatDelegate.setDefaultNightMode(1);
            } else {
                edit.putBoolean("darkMode", true);
                edit.apply();
                AppCompatDelegate.setDefaultNightMode(2);
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) C1092R.layout.activity_home);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        this.mAdView = (AdView) findViewById(C1092R.C1095id.adView);
        this.mAdView.loadAd(new AdRequest.Builder().build());
        this.mAdView.setAdListener(new AdListener() {
            public void onAdClicked() {
                super.onAdClicked();
            }

            public void onAdClosed() {
                super.onAdClosed();
            }

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
            }

            public void onAdImpression() {
                super.onAdImpression();
            }

            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdOpened() {
                super.onAdOpened();
            }
        });
        if (getNightMode()) {
            this.isInNightMode = true;
            AppCompatDelegate.setDefaultNightMode(2);
        } else {
            this.isInNightMode = false;
            AppCompatDelegate.setDefaultNightMode(1);
        }
        ActionBar supportActionBar = getSupportActionBar();
        Objects.requireNonNull(supportActionBar);
        supportActionBar.setElevation(0.0f);
        new MySqllite(this);
        this.loadinglayout = (ConstraintLayout) findViewById(C1092R.C1095id.loadinglayout);
        this.addtextfilebutton = (FloatingActionButton) findViewById(C1092R.C1095id.floatingActionButton3);
        this.tabLayout = (TabLayout) findViewById(C1092R.C1095id.tabLayout);
        this.viewPager2 = (ViewPager2) findViewById(C1092R.C1095id.viewPager2);
        this.f169fm = getSupportFragmentManager();
        HomeFragmentAdapter homeFragmentAdapter = new HomeFragmentAdapter(this.f169fm, getLifecycle());
        this.adapter = homeFragmentAdapter;
        this.viewPager2.setAdapter(homeFragmentAdapter);
        names = new ArrayList();
        this.readabledates = new ArrayList();
        this.loadinglayout.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });
        this.tabLayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabUnselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
                HomeActivity.this.viewPager2.setCurrentItem(tab.getPosition());
            }
        });
        this.viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            public void onPageSelected(int i) {
                HomeActivity.this.tabLayout.selectTab(HomeActivity.this.tabLayout.getTabAt(i));
            }
        });
        this.addtextfilebutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                HomeActivity.this.textFileOpener.launch(new Intent().setType("text/plain").setAction("android.intent.action.GET_CONTENT"));
            }
        });
        Intent intent = getIntent();
        if (intent != null && this.isintentfresh) {
            isReadStoragePermissionGranted();
            String action = intent.getAction();
            String type = intent.getType();
            Bundle extras = intent.getExtras();
            if ("android.intent.action.VIEW".equals(action)) {
                this.uri = intent.getData();
                getIntent().removeExtra("key");
                checkNopen(this.uri);
                loadInterstitialAd();
            } else if (!"android.intent.action.SEND".equals(action) || type == null) {
                if ("android.intent.action.SEND_MULTIPLE".equals(action) && type != null) {
                    ArrayList parcelableArrayListExtra = intent.getParcelableArrayListExtra("android.intent.extra.STREAM");
                    String path = ((Uri) parcelableArrayListExtra.get(0)).getPath();
                    if (path.contains(".")) {
                        path = path.substring(path.lastIndexOf(".") + 1);
                    }
                    if (path.equals("txt") || ((Uri) parcelableArrayListExtra.get(0)).getPath().contains("export_chat")) {
                        getIntent().removeExtra("key");
                        checkNopen((Uri) parcelableArrayListExtra.get(0));
                        loadInterstitialAd();
                        return;
                    }
                    Toast.makeText(this, "Unsupported files", 0).show();
                }
            } else if (type.equalsIgnoreCase("text/plain")) {
                this.uri = (Uri) extras.get("android.intent.extra.STREAM");
                getIntent().removeExtra("key");
                checkNopen(this.uri);
                loadInterstitialAd();
            } else {
                this.uri = (Uri) extras.get("android.intent.extra.STREAM");
                String obj = extras.get("android.intent.extra.STREAM").toString();
                if (obj.contains(".")) {
                    obj = obj.substring(obj.lastIndexOf(".") + 1);
                }
                if (obj.equals("txt")) {
                    getIntent().removeExtra("key");
                    checkNopen(this.uri);
                    loadInterstitialAd();
                    return;
                }
                Toast.makeText(this, "Unsupported file format", 0).show();
            }
        }
    }

    public void loadInterstitialAd() {
        this.isinterstitialadfinished = false;
        InterstitialAd.load(this, "ca-app-pub-2813592783630195/9571135356", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            public void onAdLoaded(InterstitialAd interstitialAd) {
                InterstitialAd unused = HomeActivity.this.mInterstitialAd = interstitialAd;
                HomeActivity.this.mInterstitialAd.show(HomeActivity.this);
                HomeActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    public void onAdClicked() {
                    }

                    public void onAdImpression() {
                    }

                    public void onAdShowedFullScreenContent() {
                    }

                    public void onAdDismissedFullScreenContent() {
                        InterstitialAd unused = HomeActivity.this.mInterstitialAd = null;
                        HomeActivity.this.isinterstitialadfinished = true;
                        if (HomeActivity.this.ischataddedandreadytolaunch) {
                            Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                            intent.putExtra("fname", HomeActivity.this.firstName);
                            intent.putExtra("sname", HomeActivity.this.secondName);
                            intent.putExtra("zname", HomeActivity.this.firstName);
                            intent.putExtra("tablename", HomeActivity.this.tablename);
                            HomeActivity.this.startActivity(intent);
                            HomeActivity.this.firstName = "";
                            HomeActivity.this.secondName = "";
                        }
                    }

                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        InterstitialAd unused = HomeActivity.this.mInterstitialAd = null;
                        HomeActivity.this.isinterstitialadfinished = true;
                        if (HomeActivity.this.ischataddedandreadytolaunch) {
                            Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                            intent.putExtra("fname", HomeActivity.this.firstName);
                            intent.putExtra("sname", HomeActivity.this.secondName);
                            intent.putExtra("zname", HomeActivity.this.firstName);
                            intent.putExtra("tablename", HomeActivity.this.tablename);
                            HomeActivity.this.startActivity(intent);
                            HomeActivity.this.firstName = "";
                            HomeActivity.this.secondName = "";
                        }
                    }
                });
            }

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                InterstitialAd unused = HomeActivity.this.mInterstitialAd = null;
                HomeActivity.this.isinterstitialadfinished = true;
                if (HomeActivity.this.ischataddedandreadytolaunch) {
                    Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                    intent.putExtra("fname", HomeActivity.this.firstName);
                    intent.putExtra("sname", HomeActivity.this.secondName);
                    intent.putExtra("zname", HomeActivity.this.firstName);
                    intent.putExtra("tablename", HomeActivity.this.tablename);
                    HomeActivity.this.startActivity(intent);
                    HomeActivity.this.firstName = "";
                    HomeActivity.this.secondName = "";
                }
            }
        });
    }

    public void checkNopen(final Uri uri2) {
        messageList.clear();
        this.f170ss = "";
        this.loadinglayout.setVisibility(0);
        this.ischataddedandreadytolaunch = false;
        new Thread(new Runnable() {
            /* JADX WARNING: Can't wrap try/catch for region: R(10:46|(5:48|(1:50)|52|(1:54)|57)|58|(1:60)|62|(1:64)|67|68|69|70) */
            /* JADX WARNING: Code restructure failed: missing block: B:24:0x0090, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$500(r4, r4.temp) == false) goto L_0x0092;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:28:0x00ac, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.temp).equals(r1.this$0.date) == false) goto L_0x00ae;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:29:0x00ae, code lost:
                r4 = r1.this$0;
                r4.date = com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.temp);
                r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList;
                r9 = r1.this$0;
                r4.add(com.vinaykpro.whatsviewer.HomeActivity.access$700(r9, r9.date));
             */
            /* JADX WARNING: Code restructure failed: missing block: B:36:0x00f3, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$500(r4, r4.temp0) == false) goto L_0x00f5;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:40:0x010f, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.temp0).equals(r1.this$0.date) == false) goto L_0x0111;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:41:0x0111, code lost:
                r4 = r1.this$0;
                r4.date = com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.temp0);
                r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList;
                r9 = r1.this$0;
                r4.add(com.vinaykpro.whatsviewer.HomeActivity.access$700(r9, r9.date));
             */
            /* JADX WARNING: Code restructure failed: missing block: B:51:0x0169, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$500(r4, r4.temp0) == false) goto L_0x016b;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:55:0x0185, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.temp0).equals(r1.this$0.date) == false) goto L_0x0187;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:56:0x0187, code lost:
                r4 = r1.this$0;
                r4.date = com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.temp0);
                r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList;
                r9 = r1.this$0;
                r4.add(com.vinaykpro.whatsviewer.HomeActivity.access$700(r9, r9.date));
             */
            /* JADX WARNING: Code restructure failed: missing block: B:61:0x01bd, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$500(r4, r4.f170ss) == false) goto L_0x01bf;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:65:0x01d9, code lost:
                if (com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.f170ss).equals(r1.this$0.date) == false) goto L_0x01db;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:66:0x01db, code lost:
                r4 = r1.this$0;
                r4.date = com.vinaykpro.whatsviewer.HomeActivity.access$600(r4, r4.f170ss);
                r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList;
                r9 = r1.this$0;
                r4.add(com.vinaykpro.whatsviewer.HomeActivity.access$700(r9, r9.date));
             */
            /* JADX WARNING: Missing exception handler attribute for start block: B:69:0x0207 */
            /* JADX WARNING: Removed duplicated region for block: B:109:0x001f A[LOOP:0: B:3:0x001f->B:109:0x001f, LOOP_END, SYNTHETIC] */
            /* JADX WARNING: Removed duplicated region for block: B:111:0x0258 A[SYNTHETIC] */
            /* JADX WARNING: Removed duplicated region for block: B:74:0x023b A[Catch:{ Exception -> 0x03b1 }] */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r22 = this;
                    r1 = r22
                    r2 = 0
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    android.content.ContentResolver r0 = r0.getContentResolver()     // Catch:{ Exception -> 0x03b1 }
                    android.net.Uri r3 = r3     // Catch:{ Exception -> 0x03b1 }
                    java.io.InputStream r0 = r0.openInputStream(r3)     // Catch:{ Exception -> 0x03b1 }
                    java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch:{ Exception -> 0x03b1 }
                    r3.<init>(r0)     // Catch:{ Exception -> 0x03b1 }
                    java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch:{ Exception -> 0x03b1 }
                    r0.<init>(r3)     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r3 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    r3.clear()     // Catch:{ Exception -> 0x03b1 }
                    r3 = 0
                L_0x001f:
                    boolean r4 = r0.ready()     // Catch:{ Exception -> 0x03b1 }
                    r5 = 2
                    java.lang.String r6 = "\n"
                    r7 = 1
                    java.lang.String r8 = ""
                    if (r4 == 0) goto L_0x0267
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r0.readLine()     // Catch:{ Exception -> 0x03b1 }
                    r4.f170ss = r9     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetMessage(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x0147
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetName(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x0147
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetTime(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x0147
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.f170ss     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.getName(r10)     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.contains(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x006e
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.f170ss     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.getName(r10)     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                L_0x006e:
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    int r4 = r4.size()     // Catch:{ Exception -> 0x03b1 }
                    if (r4 < r7) goto L_0x0078
                    com.vinaykpro.whatsviewer.HomeActivity.isfilevalid = r7     // Catch:{ Exception -> 0x03b1 }
                L_0x0078:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.istempavailable     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x00d7
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x0092
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x00ae
                L_0x0092:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x00c5
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x00c5
                L_0x00ae:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    r4.date = r9     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.getReadableDate(r10)     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                L_0x00c5:
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.temp     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.istempavailable = r2     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.temp = r8     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x0135
                L_0x00d7:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x0135
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x00f5
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x0111
                L_0x00f5:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x0128
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x0128
                L_0x0111:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    r4.date = r9     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.getReadableDate(r10)     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                L_0x0128:
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.temp0     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.istemp0available = r2     // Catch:{ Exception -> 0x03b1 }
                L_0x0135:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.istemp0available = r7     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    r4.temp0 = r9     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    r4.temp = r9     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x0231
                L_0x0147:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetTime(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x0211
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.istemp0available     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x01ab
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x016b
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x0187
                L_0x016b:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x019e
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x019e
                L_0x0187:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.temp0     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    r4.date = r9     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.getReadableDate(r10)     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                L_0x019e:
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.temp0     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.istemp0available = r2     // Catch:{ Exception -> 0x03b1 }
                L_0x01ab:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x01bf
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x01db
                L_0x01bf:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x01f2
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x01f2
                L_0x01db:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    r4.date = r9     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.date     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.getReadableDate(r10)     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                L_0x01f2:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x0207 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x0207 }
                    com.vinaykpro.whatsviewer.HomeActivity r10 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x0207 }
                    java.lang.String r10 = r10.f170ss     // Catch:{ Exception -> 0x0207 }
                    java.lang.String r11 = "-"
                    int r10 = r10.indexOf(r11)     // Catch:{ Exception -> 0x0207 }
                    int r10 = r10 + r5
                    java.lang.String r9 = r9.substring(r10)     // Catch:{ Exception -> 0x0207 }
                    r4.f170ss = r9     // Catch:{ Exception -> 0x0207 }
                L_0x0207:
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r9.f170ss     // Catch:{ Exception -> 0x03b1 }
                    r4.add(r9)     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x0231
                L_0x0211:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.istempavailable = r7     // Catch:{ Exception -> 0x03b1 }
                    java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x03b1 }
                    r4.<init>()     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.temp     // Catch:{ Exception -> 0x03b1 }
                    r4.append(r10)     // Catch:{ Exception -> 0x03b1 }
                    r4.append(r6)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r10 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r10.f170ss     // Catch:{ Exception -> 0x03b1 }
                    r4.append(r10)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x03b1 }
                    r9.temp = r4     // Catch:{ Exception -> 0x03b1 }
                L_0x0231:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.date     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x024f
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    boolean r4 = r4.canigetDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == 0) goto L_0x024f
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.f170ss     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = r4.getDate(r9)     // Catch:{ Exception -> 0x03b1 }
                    r4.date = r9     // Catch:{ Exception -> 0x03b1 }
                L_0x024f:
                    int r3 = r3 + r7
                    r4 = 30
                    if (r3 < r4) goto L_0x001f
                    boolean r4 = com.vinaykpro.whatsviewer.HomeActivity.isfilevalid     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != 0) goto L_0x001f
                    java.util.List<java.lang.String> r0 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    r0.clear()     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity$9$1 r3 = new com.vinaykpro.whatsviewer.HomeActivity$9$1     // Catch:{ Exception -> 0x03b1 }
                    r3.<init>()     // Catch:{ Exception -> 0x03b1 }
                    r0.runOnUiThread(r3)     // Catch:{ Exception -> 0x03b1 }
                L_0x0267:
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    boolean r0 = r0.istempavailable     // Catch:{ Exception -> 0x03b1 }
                    if (r0 == 0) goto L_0x027b
                    java.util.List<java.lang.String> r0 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = r3.temp     // Catch:{ Exception -> 0x03b1 }
                    r0.add(r3)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.istempavailable = r2     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x0292
                L_0x027b:
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r0 = r0.temp0     // Catch:{ Exception -> 0x03b1 }
                    boolean r0 = r0.equals(r8)     // Catch:{ Exception -> 0x03b1 }
                    if (r0 != 0) goto L_0x0292
                    java.util.List<java.lang.String> r0 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = r3.temp0     // Catch:{ Exception -> 0x03b1 }
                    r0.add(r3)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.istemp0available = r2     // Catch:{ Exception -> 0x03b1 }
                L_0x0292:
                    boolean r0 = com.vinaykpro.whatsviewer.HomeActivity.isfilevalid     // Catch:{ Exception -> 0x03b1 }
                    if (r0 == 0) goto L_0x03c1
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.prompt()     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.MySqllite r0 = new com.vinaykpro.whatsviewer.MySqllite     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.<init>(r3)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4 = 10
                    java.lang.String r4 = com.vinaykpro.whatsviewer.HomeActivity.generateRandomTableName(r4)     // Catch:{ Exception -> 0x03b1 }
                    r3.tablename = r4     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = "online"
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r9 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    java.lang.Object r9 = r9.get(r2)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r9 = (java.lang.String) r9     // Catch:{ Exception -> 0x03b1 }
                    r4.firstName = r9     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    int r4 = r4.size()     // Catch:{ Exception -> 0x03b1 }
                    if (r4 != r5) goto L_0x02cf
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r5 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    java.lang.Object r5 = r5.get(r7)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r5 = (java.lang.String) r5     // Catch:{ Exception -> 0x03b1 }
                    r4.secondName = r5     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x0330
                L_0x02cf:
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r4.secondName = r8     // Catch:{ Exception -> 0x03b1 }
                    r4 = 0
                L_0x02d4:
                    java.util.List<java.lang.String> r5 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    int r5 = r5.size()     // Catch:{ Exception -> 0x03b1 }
                    if (r4 >= r5) goto L_0x0326
                    java.util.List<java.lang.String> r5 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    int r5 = r5.size()     // Catch:{ Exception -> 0x03b1 }
                    int r5 = r5 - r7
                    if (r4 != r5) goto L_0x0303
                    java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x03b1 }
                    r5.<init>()     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.secondName     // Catch:{ Exception -> 0x03b1 }
                    r5.append(r10)     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r10 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    java.lang.Object r10 = r10.get(r4)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = (java.lang.String) r10     // Catch:{ Exception -> 0x03b1 }
                    r5.append(r10)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x03b1 }
                    r9.secondName = r5     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x0323
                L_0x0303:
                    java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x03b1 }
                    r5.<init>()     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r9 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r9.secondName     // Catch:{ Exception -> 0x03b1 }
                    r5.append(r10)     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r10 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    java.lang.Object r10 = r10.get(r4)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = (java.lang.String) r10     // Catch:{ Exception -> 0x03b1 }
                    r5.append(r10)     // Catch:{ Exception -> 0x03b1 }
                    r5.append(r6)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x03b1 }
                    r9.secondName = r5     // Catch:{ Exception -> 0x03b1 }
                L_0x0323:
                    int r4 = r4 + 1
                    goto L_0x02d4
                L_0x0326:
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    int r4 = r4.size()     // Catch:{ Exception -> 0x03b1 }
                    if (r4 == r7) goto L_0x0330
                    java.lang.String r3 = "tap here for group info"
                L_0x0330:
                    r16 = r3
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r10 = r3.firstName     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r11 = r3.tablename     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r12 = r3.firstName     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r13 = r3.secondName     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r14 = r3.firstName     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r3 = com.vinaykpro.whatsviewer.HomeActivity.names     // Catch:{ Exception -> 0x03b1 }
                    int r15 = r3.size()     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r17 = ""
                    java.lang.String r18 = ""
                    r19 = 0
                    r20 = 0
                    r21 = 0
                    r9 = r0
                    r9.addText(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = r3.tablename     // Catch:{ Exception -> 0x03b1 }
                    java.util.List<java.lang.String> r4 = com.vinaykpro.whatsviewer.HomeActivity.messageList     // Catch:{ Exception -> 0x03b1 }
                    r0.addChatToContact(r3, r4)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.ischataddedandreadytolaunch = r7     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    boolean r0 = r0.isinterstitialadfinished     // Catch:{ Exception -> 0x03b1 }
                    if (r0 == 0) goto L_0x03c1
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.isinterstitialadfinished = r2     // Catch:{ Exception -> 0x03b1 }
                    android.content.Intent r0 = new android.content.Intent     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.Class<com.vinaykpro.whatsviewer.MainActivity> r4 = com.vinaykpro.whatsviewer.MainActivity.class
                    r0.<init>(r3, r4)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = "fname"
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.firstName     // Catch:{ Exception -> 0x03b1 }
                    r0.putExtra(r3, r4)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = "sname"
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.secondName     // Catch:{ Exception -> 0x03b1 }
                    r0.putExtra(r3, r4)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = "zname"
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.firstName     // Catch:{ Exception -> 0x03b1 }
                    r0.putExtra(r3, r4)     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r3 = "tablename"
                    com.vinaykpro.whatsviewer.HomeActivity r4 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    java.lang.String r4 = r4.tablename     // Catch:{ Exception -> 0x03b1 }
                    r0.putExtra(r3, r4)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r3 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity$9$2 r4 = new com.vinaykpro.whatsviewer.HomeActivity$9$2     // Catch:{ Exception -> 0x03b1 }
                    r4.<init>(r0)     // Catch:{ Exception -> 0x03b1 }
                    r3.runOnUiThread(r4)     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.firstName = r8     // Catch:{ Exception -> 0x03b1 }
                    com.vinaykpro.whatsviewer.HomeActivity r0 = com.vinaykpro.whatsviewer.HomeActivity.this     // Catch:{ Exception -> 0x03b1 }
                    r0.secondName = r8     // Catch:{ Exception -> 0x03b1 }
                    goto L_0x03c1
                L_0x03b1:
                    r0 = move-exception
                    com.vinaykpro.whatsviewer.HomeActivity.isfilevalid = r2
                    r0.printStackTrace()
                    com.vinaykpro.whatsviewer.HomeActivity r2 = com.vinaykpro.whatsviewer.HomeActivity.this
                    com.vinaykpro.whatsviewer.HomeActivity$9$3 r3 = new com.vinaykpro.whatsviewer.HomeActivity$9$3
                    r3.<init>(r0)
                    r2.runOnUiThread(r3)
                L_0x03c1:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.vinaykpro.whatsviewer.HomeActivity.C10789.run():void");
            }
        }).start();
    }

    /* access modifiers changed from: private */
    public boolean canigetMessage(String str) {
        int indexOf = str.indexOf("-");
        return (indexOf == -1 || str.indexOf(":", indexOf) == -1) ? false : true;
    }

    /* access modifiers changed from: private */
    public boolean canigetName(String str) {
        int indexOf = str.indexOf("-");
        return (indexOf == -1 || str.indexOf(":", indexOf) == -1) ? false : true;
    }

    /* access modifiers changed from: private */
    public boolean canigetTime(String str) {
        int indexOf = str.indexOf(",");
        return (indexOf == -1 || str.indexOf("-", indexOf) == -1) ? false : true;
    }

    /* access modifiers changed from: private */
    public boolean canigetDate(String str) {
        int indexOf = str.indexOf(",");
        if (indexOf <= 0 || indexOf > 10 || str.indexOf(47) > 9 || str.substring(0, indexOf).split("/").length != 3) {
            return false;
        }
        return true;
    }

    /* access modifiers changed from: private */
    public String getDate(String str) {
        return str.substring(0, str.indexOf(","));
    }

    /* access modifiers changed from: private */
    public String getReadableDate(String str) {
        int parseInt = Integer.parseInt(str.substring(0, str.indexOf("/")));
        String substring = str.substring(str.indexOf("/") + 1);
        int parseInt2 = Integer.parseInt(substring.substring(0, substring.indexOf("/")));
        if (parseInt2 > 12 && parseInt <= 12) {
            int i = parseInt2;
            parseInt2 = parseInt;
            parseInt = i;
        }
        int parseInt3 = Integer.parseInt(substring.substring(substring.indexOf("/") + 1));
        if (parseInt3 < 100) {
            return parseInt + " " + this.months[parseInt2 - 1] + " 20" + parseInt3;
        }
        return parseInt + " " + this.months[parseInt2 - 1] + " " + parseInt3;
    }

    public String getFlippedDate(String str) {
        String[] split = str.split(" ");
        int parseInt = Integer.parseInt(split[0]);
        int monthIndex = getMonthIndex(split[1]);
        return getReadableDate(monthIndex + "/" + parseInt + "/" + split[2]);
    }

    public int getMonthIndex(String str) {
        int i = 1;
        int i2 = 0;
        while (true) {
            String[] strArr = this.months;
            if (i2 >= strArr.length) {
                return i;
            }
            if (str.equals(strArr[i2])) {
                i = i2 + 1;
            }
            i2++;
        }
    }

    private String getMessage(String str) {
        return str.substring(str.indexOf(":", str.indexOf("-")) + 2);
    }

    /* access modifiers changed from: private */
    public String getName(String str) {
        int indexOf = str.indexOf("-");
        return str.substring(indexOf + 2, str.indexOf(":", indexOf));
    }

    public static String generateRandomTableName(int i) {
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < i; i2++) {
            sb.append("abcdefghijklmnopqrstuvwxyz".charAt(secureRandom.nextInt(26)));
        }
        return sb.toString();
    }

    public boolean isReadStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 2);
        return false;
    }

    public boolean isWriteStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 103);
        return false;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 102) {
            int i2 = iArr[0];
        }
    }

    public boolean getNightMode() {
        return getSharedPreferences("SP", 0).getBoolean("darkMode", false);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        if (this.ischataddedandreadytolaunch) {
            this.loadinglayout.setVisibility(8);
        }
    }
}
